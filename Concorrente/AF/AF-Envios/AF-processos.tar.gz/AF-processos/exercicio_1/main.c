#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>

//       (pai)      
//         |        
//    +----+----+
//    |         |   
// filho_1   filho_2


// ~~~ printfs  ~~~
// pai (ao criar filho): "Processo pai criou %d\n"
//    pai (ao terminar): "Processo pai finalizado!\n"
//  filhos (ao iniciar): "Processo filho %d criado\n"

// Obs:
// - pai deve esperar pelos filhos antes de terminar!


void processoFilho() {
    printf("Processo filho %d criado\n", getpid());
    fflush(stdout);
    exit(0);
}


void processoPai(const pid_t pidFilho) {
    printf("Processo pai criou %d\n", pidFilho);
    fflush(stdout);
}

void criaFilhos(const pid_t pidPai, const int qtdFilhos) {
    for (int i = 0; i < qtdFilhos; i++) {
        // Cria um filho
        pid_t pidFilho = fork();
        if (pidFilho == 0) { 
            // Se pidFilho == 0 então estamos no contexto do processo filho
            processoFilho();
        } else {
            // Se não, estamos no contexto do processo pai
            processoPai(pidFilho);
        }
    }
    // Espera todos os processos filhos encerrarem
    while(wait(NULL) >= 0);
}

int main(int argc, char** argv) {

    // ....

    /*************************************************
     * Dicas:                                        *
     * 1. Leia as intruções antes do main().         *
     * 2. Faça os prints exatamente como solicitado. *
     * 3. Espere o término dos filhos                *
     *************************************************/
    const int qtdFilhos = 2;
    criaFilhos(getpid(), qtdFilhos);
    printf("Processo pai finalizado!\n");   
    return 0;
}
